﻿$ini=Get-Content -Path hymulti-TestEnvs.INI

$ini |
 where { $_ -match "(.*),(.*),(.*)" } |
 select { $matches}
 
 $pattern ="(.*),(.*<ini>),(.*)"
 $ini |
 ForEach-Object {if($_ -match $pattern) {$matches.values[1]}}
 